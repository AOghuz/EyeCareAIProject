$(document).ready(function() {

  $(".datepicker").datepicker({
    prevText: '<i class="far fa-angle-left"></i>',
    nextText: '<i class="far fa-angle-right"></i>'
  });
});